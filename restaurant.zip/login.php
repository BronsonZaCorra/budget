<?php include('../config/constants.php') ?>

<!DOCTYPE html>
<html>

<head>
<title>Login - Food Order System</title>
<link rel="stylesheet" href="../restaurant/css/admin.css">

</head>

<body>
    <div class="login text-center">
        <h1>STAFF LOGIN</h1>
<br>

<?php 
if (isset($_SESSION['login']))
{
echo $_SESSION['login'];
unset($_SESSION['login']);

}

if (isset($_SESSION['logout']))

{
echo $_SESSION['logout'];
unset($_SESSION['logout']);

}

if (isset($_SESSION['invalid-login']))

{
echo $_SESSION['invalid-login'];
unset($_SESSION['invalid-login']);

}


?>

        <!-- Login Form Starts Here -->
        <form action="" method="POST">
            Staff ID:<br>
         <input type="text" name="ID" placeholder="Enter ID #">
            <br><br>
         Password:<br>
            <input type="password" name="password" placeholder="Enter Password">
            <br><br>

        <input type="submit" name="submit" value="Login" class="btn-primary">



        </form>


<Br><br>
        <p>Created By - <a href="www.BronsonBuilds.com">ZaCorra Bronson</a></p>


    </div>

</body>

</html>

<?php
//Check if submit button is clicked

if(isset($_POST['submit'])){
//echo "Button Clicked";

//Get Data from form

$ID=$_POST['ID'];
$password=md5($_POST['password']);


//Check if user exists

$sql = "SELECT * FROM tbl_admin WHERE ID='$ID' AND Password='$password'";

//Execute query
$res = mysqli_query($conn,$sql);

//If user exists, count == 1, otherwise user invalid or DNE

$count = mysqli_num_rows($res);

if ($count==1){
//User exists and is available
$_SESSION['login']="<div class='success'>Login Successful</div>";
$_SESSION['id']= $ID ; //check if user is logged in yes=logout no =unset

//Redirect to home page Dashboard

header('location:'.SITEURL.'/admin/index.php');



}

else{
//User does not exist or is unavailable
$_SESSION['logout']="<div class='error'>Incorrect User or Password</div>";

//Redirect to home page Dashboard

header('location:'.SITEURL.'admin/login.php');
}


}





?>