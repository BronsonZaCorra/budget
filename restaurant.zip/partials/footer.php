<!--Footer Section Starts-->
<section>
<div class="footer">
<div class="wrapper text-center">
<p>2021 All Rights Reserved, Compass Kitchen. Developed by <a href="#">ZaCorra Bronson</a> </p>    
</div>
</div>
</section>
<!--Footer Section Ends-->

</body>



</html>