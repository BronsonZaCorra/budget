
<?php

//authorization, access - control
//Check is user is logged in

if (!isset($_SESSION['id']))
//user id is null
                    

{

//redirect to login page w error

//1 admin
$_SESSION['invalid-login']= "<div class='error'> Please Login to Access Admin Portal.</div>";
//redirect to login page
//can customize which tab you want to see first
header('location:'.SITEURL.'admin/login.php');

}


?>