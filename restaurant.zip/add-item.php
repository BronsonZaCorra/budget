
<?php  include('partials/menu.php');  ?>




<div class="main-content">
        <div class="wrapper">
                 <h1>ADD ITEM</h1>
                 <br>

<?php


 if (isset($_SESSION['add']))
 {
     echo $_SESSION['add'];
     unset($_SESSION['add']);
 }

 if (isset($_SESSION['upload']))
                 {
                     echo $_SESSION['upload'];
                     unset($_SESSION['upload']);
                 }


?>

<br>

<form action="" method="POST" enctype="multipart/form-data">
    <table class="tbl-40">

    <tr>
        <td>Item Name:</td>
<td> <input required type="text" name="title" placeholder="Item title"  ></td>
    </tr>
    
    <tr>
        <td>Item available?</td>
<td> <input required type="radio" name="available" value="Yes" >Yes
 <input type="radio" name="available" value="No" >No</td>
    </tr>

      
    <tr>
        <td>Item Featured?</td>
<td> <input required type="radio" name="featured" value="Yes" >Yes
 <input type="radio" name="featured" value="No"  >No</td>
</tr>

<tr>
        <td>Item Image (optional) </td>
<td> <input  type="file" name="image" >
</tr>


<tr>
    <td colspan="2">    
        <input type="submit" name="submit" value="Add Item" class="btn-secondary">
    </td>
</tr>

    </table>

</form>


<?php

//check is submit button is clicked
if (isset($_POST['submit']))
{
    //echo "Clicked";

     $title = $_POST['title'];

   //set defautlt radio button values if not set


   if (isset($_POST['featured']))
   {
//Get value from form

   $featured = $_POST['featured'];

   }
   else
   {
       //set default value
       $featured = "No";
   }

   if (isset($_POST['available']))
   {
//Get value from form

   $available = $_POST['available'];

   }
   else
   {
       //set default value
       $available = "No";
   }

  // echo $featured;
   //echo $available;


   //check if image is uploaded and set value for image name
   //print_r($_FILES['image']);

   //die();//break code here



   if (isset($_FILES['image']['name']))
   {
//upload image , need name  source and destination path

$image_name = $_FILES['image']['name'];
$source_path=$_FILES['image']['tmp_name'];

$destination_path = "../restaurant/css/images/items/".$image_name;
//upload image

$upload = move_uploaded_file($source_path,$destination_path);

//check for successfull upload

if($upload==false)
{
$_SESSION['upload']= "<div class='error'> Image not Uploaded </div>";


//stop the process
die();
}
   }
   else
   {
       //don't upload image and set value to " "
       $image_name = "";
   }
   //create sql query to insert item into database
$sql = "INSERT INTO tbl_menu SET
title='$title',
img = '$image_name',
featured='$featured',
available = '$available'

";
// echo $sql; check correcrt data entry
$res = mysqli_query($conn,$sql);


if ($res==true)
{
   //query executed and was successfull
   $_SESSION['add']="<div class='success'>Item Added successfully</div>";

   //redirect to manage menu page
   header('location:'.SITEURL.'admin/manage-menu.php');
 
}
else
{
    //failed to execute query successfully
    $_SESSION['add']="<div class='error'>Item Not Added</div>";

    //redirect to add item page
 
    header('location:'.SITEURL.'admin/add-item.php');
}

};


?>



</div>
        </div>

<?php include('partials/footer.php');?>


