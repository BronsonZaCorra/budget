<?php include ("partials/menu.php"); ?>

<section>
<div class="main-content">
<div class="wrapper">
    <h1>UPDATE STAFF</h1><br>

<?php 
    //Get Staff ID
$ID= $_GET['id'];
    //Create SQL Query to Get Staff Record

    $sql ="SELECT * FROM tbl_admin WHERE ID=$ID";

    //Execute Query

    $res=mysqli_query($conn,$sql);

    //Check query status

    if($res==TRUE){
    //Check if data is available
    $count = mysqli_num_rows($res);
    //Check whether we have staff data
    if ($count==1){
        //Get Record
       echo "Updating Record For: $ID";
        $row=mysqli_fetch_assoc($res);

        $F_Name = $row['F_Name'];
        $L_Name = $row['L_Name'];

    }
    else{
        //Redirect to Manage Admin Page
  
        header('location:'.SITEURL.'admin/manage-admin.php');
    }
        
    }

?>
    <form action="" method="POST">
<table class="tbl-40">

<tr>
    <td>First Name: </td>
    <td><input  type="text" name="F_Name" value="<?php echo $F_Name?>"></td>
</tr>
<tr>
    <td>Last Name: </td>
    <td><input  type="text" name="L_Name" value="<?php echo $L_Name?>"></td>
</tr>


<tr>
    <td colspan="2"> 
        <input  type="hidden" name="ID" value="<?php echo $ID ?>">
        <input type="submit" name="submit" value="Update Staff"  class="btn-secondary"> 
    </td>
</tr>
</table>
     </form>
    </div>
</div>

<?php
//Check if Button is Clicked
if (isset($_POST['submit'])){

    //Get all values from form that need to be updated 
     $ID = $_POST['ID'];
    $F_Name = $_POST['F_Name'];
    $L_Name = $_POST['L_Name'];


    //Create SQL Query to Update Admin

    $sql = "UPDATE tbl_admin SET
    F_Name = '$F_Name',
    L_Name = '$L_Name'

    WHERE id='$ID'
    ";

    //Execute Query

    $res = mysqli_query($conn,$sql);

    //Check Query Execution Status

    if ($res==TRUE)
    {
//Query Executed and Admin Updates
$_SESSION['update']="<div class='success'>Admin Successfully Updated</div>";

//Redirect to Manage Admin PAge

header('location:'.SITEURL.'admin/manage-admin.php');

    }
    else{
//Query Failed and Admin not Updated
$_SESSION['update']="<div class='error'>Admin Not Updated</div>";

//Redirect to Manage Admin PAge

header('location:'.SITEURL.'admin/manage-admin.php');

    }


}


?>


<?php include ("partials/footer.php"); ?>

