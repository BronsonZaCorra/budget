<?php include ("partials/menu.php"); ?>


<div class="main-content">
<div class="wrapper">
<?php

//1. Get the ID of the admin to be deleted
 $ID = $_GET['id'];

//2. Create SQL Query to Delete Staff
$sql = "DELETE FROM tbl_admin WHERE id=$ID";

//Execute the Query
$res = mysqli_query($conn,$sql);


//Check status of Query
if ($res==TRUE){
//Query Successful
//echo "Staff Deleted Successfully";
//Create Session Variable to Display Message
$_SESSION['delete']="<div class='success'>Staff Deleted Successfully</div>";
//Redirect to Manage Admin Page with Message (success)
header('location:'.SITEURL.'admin/manage-admin.php');

} else{
//Query Failed
//echo "Query Failed, Please Try Again";
//Create Session Variable to Display Message

$_SESSION['delete']="<div class='error'>Task Failed: Staff Not Deleted, Try Again</div>";
header('localhost:'.SITEURL.'admin/manage-admin.php');
}




?>
</div>
</div>


<?php include ("partials/footer.php"); ?>