<?php include ("partials/menu.php"); ?>



<!--Content Section Starts-->
<section>
<div class="main-content">
<div class="wrapper">
    <h1>MANAGE STAFF</h1><br>

<?php  

if (isset($_SESSION['add'])){
echo $_SESSION['add']; //Display System Message

unset($_SESSION['add']); //Removing Session Message

}

if (isset($_SESSION['delete'])){

   echo $_SESSION['delete'];
   unset ($_SESSION['delete']);

}

if (isset($_SESSION['update'])){

   echo $_SESSION['update'];
   unset ($_SESSION['update']);

}

if (isset($_SESSION['incorrect-user'])){

   echo $_SESSION['incorrect-user'];
   unset ($_SESSION['incorrect-user']);

}

if (isset($_SESSION['confirmation-failed'])){

   echo $_SESSION['confirmation-failed'];
   unset ($_SESSION['confirmation-failed']);

}


if (isset($_SESSION['update-success'])){

   echo $_SESSION['update-success'];
   unset ($_SESSION['update-success']);

}


?>
<br>

    <!--Add Admin Button-->
   <br> <a class="btn-primary" href="add-admin.php">Add STAFF</a><br><br>
   
<table class="tbl-full">
 <tr>
    <th>ID</th>
    <th>First Name</th>
    <th>Last Name</th>
    <th>Actions</th>
 </tr>

<?php
//Query all records in admin table
$sql="SELECT * FROM tbl_admin";
//Execute Query
$res = mysqli_query($conn,$sql);

//Check for successful Query Execution
if($res==TRUE){
//Count Rows
$count = mysqli_num_rows($res); //Function to count all rows returned

//Check the number of rows 
if ($count>0){
//Table has Data
while($rows=mysqli_fetch_assoc($res)){
   //Using while loop to get all data from database
   //While loop will run as long as we have data in table


   //Get Each record
   $ID=$rows['ID'];
   $F_Name=$rows['F_Name'];
   $L_Name=$rows['L_Name'];

   //Display Values in Table
   ?>
 <tr>
<td><?php echo $ID ?></td>
<td><?php echo $F_Name ?></td>
<td><?php echo $L_Name ?></td>
<td>

<a class="btn-warning" href="<?php echo SITEURL;?>admin/update-password.php?id=<?php echo$ID; ?>">Change Password</a>
<a class="btn-secondary" href="<?php echo SITEURL;?>admin/update-admin.php?id=<?php echo$ID; ?>">Update</a>
<a class="btn-warning" href="<?php echo SITEURL;?>admin/delete-admin.php?id=<?php echo$ID; ?>">Delete</a>
</td>
 </tr>
   <?php


  
}

}
else {
//Table has no data

}
}


?>


</table>


</div>
</div>

</section>
<!--Content Section Ends-->


<?php include ("partials/footer.php"); ?>