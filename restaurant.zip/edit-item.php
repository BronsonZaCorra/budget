<?php  include('partials/menu.php');  


?>
<div class="main-content">
        <div class="wrapper">
                 <h1>Edit ITEM</h1><br>


                 <!-- Edit Item Starts-->
            


                <!-- Edit Item Ends -->

 


                <a class="btn-warning" href="#">Remove ITEM</a><br><br>

</div>

</div>



<?php include('partials/footer.php');?>