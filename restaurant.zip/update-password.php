<?php include ("partials/menu.php"); ?>

<section>
<div class="main-content">
<div class="wrapper">
    <h1>UPDATE PASSWORD</h1>
    <br>

<?php   
if(isset($_GET['id'])){

    $ID=$_GET['id'];
}

?>

    <form action="" method="POST">
<table class="tbl-40">

<tr>
    <td>Current Password: </td>
    <td><input  type="password" name="current_password" placeholder="Current Password"></td>
</tr>
<tr>
    <td>New Password: </td>
    <td><input  type="password" name="new_password" placeholder="New Password"></td>
</tr>

<tr>
    <td>Confirm New Password: </td>
    <td><input  type="password" name="confirm_password" placeholder="Confirm New Password"></td>
</tr>


<tr>
    <td colspan="2"> 
        <input  type="hidden" name="ID" value="<?php echo $ID ?>">
        <input type="submit" name="submit" value="Update Password"  class="btn-secondary"> 
    </td>
</tr>
</table>
     </form>




</div>
</div>



<?php

//Check for button click
if(isset($_POST['submit'])){

//echo "button clicked";


//1. Get Data from Form
$ID=$_POST['ID'];
$current_password= md5($_POST['current_password']);
$new_password= md5($_POST['new_password']);
$confirm_password= md5($_POST['confirm_password']);


//2. Validate current and existing data
$sql = "SELECT * FROM tbl_admin WHERE ID=$ID AND Password='$current_password'";

//Execute Query
$res = mysqli_query($conn,$sql);


if ($res==TRUE){

    //Check if user is available
    $count = mysqli_num_rows($res);
    if ($count==1){
        //ECHO "User Found and Available";

        //Check whether new passwords match

        if($new_password==$confirm_password){

//update password
$sql2= "UPDATE tbl_admin SET Password=$new_password WHERE id=$ID";

$res2=mysqli_query($conn,$sql2);

if ($res2==TRUE){

header('location:'.SITEURL.'admin/manage-admin.php');
$_SESSION['update-success'] = "<div class='success'> Password Changed Successfully</div>";
}
    else{

            //redirect to manage-admin page with error message"
            header('location:'.SITEURL.'admin/manage-admin.php');
            $_SESSION['confirmation-failed'] = "<div class='error'> Passwords do not match</div>";
            
        }
    }
}
     
    else {
        //user does not exist or is unavailable for update and redirect user
        header('location:'.SITEURL.'admin/manage-admin.php');
$_SESSION['incorrect-user'] = "<div class='error'> Incorrect User or Password </div>";



}

    }

}


?>


    
<?php include ("partials/footer.php"); ?>