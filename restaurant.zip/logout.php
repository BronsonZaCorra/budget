<?php 

//Include const.php

include('../config/constants.php');
//1.DEstory the session

session_destroy();

//2.REdirect to Login password_get_info

header('location:'.SITEURL.'admin./login.php');


?>