<?php include ("partials/menu.php"); ?>



<!--Content Section Starts-->
<section>
<div class="main-content">
<div class="wrapper">
    <h1>INBOX</h1>
    <br> <a class="btn-primary" href="#">New MESSAGE</a><br><br>
    <table class="tbl-full">
 <tr>
    <th>ID</th>
    <th>First Name</th>
    <th>Last Name</th>
    <th>Actions</th>
 </tr>

 <tr>
<td>5262</td>
<td>ZaCorra</td>
<td>Bronson</td>
<td>
<a class="btn-secondary" href="#">Update</a>
<a class="btn-warning" href="#">Delete</a>
</td>
 </tr>

 <tr>
<td>5262</td>
<td>ZaCorra</td>
<td>Bronson</td>
<td>
<a class="btn-secondary" href="#">Update</a>
<a class="btn-warning" href="#">Delete</a>
</td>
 </tr>

 <tr>
<td>5262</td>
<td>ZaCorra</td>
<td>Bronson</td>
<td>
<a class="btn-secondary" href="#">Update</a>
<a class="btn-warning" href="#">Delete</a>
</td>
 </tr>


</table>

</div>
</div>

</section>
<!--Content Section Ends-->


<?php include ("partials/footer.php"); ?>