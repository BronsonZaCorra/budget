<?php  include('partials/menu.php');  


?>
<div class="main-content">
        <div class="wrapper">
                 <h1>ADD Order</h1><br>


                 <!-- Add Order Starts-->
            


                <!-- Add Order Ends -->



</div>

</div>



<?php include('partials/footer.php');?>