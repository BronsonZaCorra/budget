<?php include ("partials/menu.php"); ?>



<!--Content Section Starts-->
<section>
<div class="main-content">
<div class="wrapper">
    <h1>MANAGE MENU</h1>
 
<?php
                 if (isset($_SESSION['add']))
                 {
                     echo $_SESSION['add'];
                     unset($_SESSION['add']);
                 }

               

?>
    <br> <br>
    <a class="btn-secondary" href="add-item.php">Add ITEM</a>
 <br><br>
    <table class="tbl-full">
 <tr>
    <th>ID</th>
    <th>First Name</th>
    <th>Last Name</th>
    <th>Actions</th>
 </tr>

 <tr>
<td>5262</td>
<td>ZaCorra</td>
<td>Bronson</td>
<td>
<a class="btn-secondary" href="#">Update</a>
<a class="btn-warning" href="#">Delete</a>
</td>
 </tr>

 <tr>
<td>5262</td>
<td>ZaCorra</td>
<td>Bronson</td>
<td>
<a class="btn-secondary" href="#">Update</a>
<a class="btn-warning" href="#">Delete</a>
</td>
 </tr>

 <tr>
<td>5262</td>
<td>ZaCorra</td>
<td>Bronson</td>
<td>
<a class="btn-secondary" href="#">Update</a>
<a class="btn-warning" href="#">Delete</a>
</td>
 </tr>


</table>
</div>
</div>

</section>
<!--Content Section Ends-->


<?php include ("partials/footer.php"); ?>