<?php include ("partials/menu.php"); ?>

<section>
<div class="main-content">
<div class="wrapper">
    <h1>ADD STAFF</h1><br>
    <?php   

if (isset($_SESSION['add'])){ //Check for Active Session

    echo $_SESSION['add']; //Display Session Message
    unset($_SESSION['add']); //Removing Session Message
}

    ?>
    <br>

    <form action="" method="POST">
<table class="tbl-40">
<tr>
    <td>Staff ID</td>
    <td><input required type="number" name="ID" min="0" max="9999" placeholder="Four Digit ID"></td>
</tr>
<tr>
    <td>First Name: </td>
    <td><input required type="text" name="F_Name" placeholder="First Name"></td>
</tr>
<tr>
    <td>Last Name: </td>
    <td><input required type="text" name="L_Name" placeholder="Last Name"></td>
</tr>
<tr>
    <td>Password:</td>
    <td><input required type="password" name="password" placeholder="Password"></td>
</tr>

<tr>
<td colspan="2"> 
<input type="submit" name="submit" value="Add Staff"  class="btn-secondary"> 
</td></tr>
</table>


    </form>
</div>
</div>

</section>


<?php include ("partials/footer.php"); ?>

<?php 
//Process values from Form and save it to database
//Check if submit button has been triggered

if(isset($_POST['submit'])){
// Button Clicked
//1.Get Data from form
 $F_Name = $_POST['F_Name'];
 $L_Name = $_POST['L_Name'];
 $ID = $_POST['ID'];
 $password = md5($_POST['password']); //Password Encryption with MD5

 
//2.SQL Query to Save Data into Database
$sql = "INSERT INTO tbl_admin SET 
ID = '$ID',
F_Name = '$F_Name',
L_Name = '$L_Name',
password = '$password'
";

//3. Execute Query and Save Data in Database

$res = mysqli_query($conn, $sql) or die(mysqli_error($conn));

//Validate successful query compeltion
if ($res==TRUE){
    //echo "Successful";
    //Create Session Variable to Display Message
    $_SESSION['add'] = "<div class='success'>Staff Added Successfully</div>";

    //Redirect Page to Manage Admin
    header("location:".SITEURL.'admin/manage-admin.php');
}

else {
    //echo "Failed: See Error Message";
    //Create Session Variable to Display Message
    $_SESSION['add'] = "<div class='error'>Failed to Add Staff<div>";

    //Redirect Page to Manage Admin
    header("location:".SITEURL.'admin/add-admin.php');
}


}

?>
